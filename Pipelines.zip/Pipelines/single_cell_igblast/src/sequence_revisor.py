# sequence_revisor.py
# Charles Macaulay
# started 08-01-2017
# updated 04-11-2018
# In addtion to converting the output from the Dana Farber Sequencing core to .fa files, this script executes a series
# of Fastx toolbox commands to create revised outputs.

import subprocess
import os
import sys
import shutil

class Sequence_revisor():

    def __init__(self, mode=None):
        self.mode = mode

    def check_make_dir(self, querydir ):
        # check to make sure the directory to hold the changed .fa sequences exists. if it doesn't. create it.
        if os.path.isdir(querydir):
            # the output path is fine.
            return querydir
        else:
            # the output directory needs to be created.
            os.makedirs(querydir)
            return querydir

    # if you download .fasta from the Dana Farber Sequencing Core, the file extension is still .seq. So the first step
    # is converting these files to the appropriate .fasta files.
    def gen_faseqs( self, inputdir ):
        # use the check_make_dir method to check for and make the directory if it's needed.
        destdir = self.check_make_dir("../curated_sequences/%s/faseqs/" %inputdir)
        # loop through all of the fasta files in the CombinedGCFasta directory.
        for filename in os.listdir("../curated_sequences/%s/" %inputdir ):
                if filename.endswith(".seq") or (self.mode == "GC" and filename.endswith(".fa")):
                    # strip off the .seq
                    name, extension = os.path.splitext(filename)
                    newname = name + ".fa"
                    shutil.copy2(str("../curated_sequences/%s/" %inputdir +filename), str(destdir + newname))

    # runs the fasta formatter to output single-line files to single_line directory.
    def gen_singlelines( self, inputdir ):
        # use the check_make_dir method to check for and make the directory if it's needed.
        destdir = self.check_make_dir("../preprocessing/single_line/%s/" %inputdir)
        # loop through all of the fasta files in the CombinedGCFasta directory.
        for filename in os.listdir("../curated_sequences/%s/faseqs/" %inputdir ):
            # check to make sure it's a fasta file.
            if filename.endswith(".fa"):
                # make output name.
                name, extension = os.path.splitext(filename)
                # make input name.
                input = "../curated_sequences/%s/faseqs/" %inputdir + filename
                # use fasta formatter to make single line FASTA
                os.system( "../../dependencies/bin/fasta_formatter -i " + input + " -o " +
                           str(destdir + name + ".SL.fa") + " -w 0")
            else:
                continue

    # runs the fastx clipper to output clipped files to clipped directory.
    # this method can take a custom adapter sequence.
    def gen_clipped( self, inputdir, adapterseq=None ):
        # use the check_make_dir method to check for and make the directory if it's needed.
        destdir = self.check_make_dir("../preprocessing/clipped/%s/" %inputdir)
        # loop through all of the single-line fasta files in single_line.
        for filename in os.listdir("../preprocessing/single_line/%s/" %inputdir ):
            # check to make sure it's a fasta file.
            if filename.endswith(".fa"):
                # make output name.
                name, extension = os.path.splitext(filename)
                # make the input name.
                input = "../preprocessing/single_line/%s/" %inputdir + filename
                # use the fastx clipper.
                if adapterseq:
                    os.system( "../../dependencies/bin/fastx_clipper -a %s -c -n -d40 -i" %adapterseq + input +
                               " -o " + str(destdir + name + ".C.fa"))
                else:
                    os.system( "../../dependencies/bin/fastx_clipper -a CCAGACTCC -c -n -d40 -i" + input +
                               " -o "  + str(destdir + name + ".C.fa"))

    # runs the fastx reverse complement on clipped fastas and outputs revcomp seqs to rev_comps directory.
    def gen_revcomps( self, inputdir ):
        # use the check_make_dir method to check for and make the directory if it's needed.
        destdir = self.check_make_dir("../preprocessing/rev_comps/%s/" %inputdir)
        # loop through all of the single-line fasta files in single_line.
        for filename in os.listdir("../preprocessing/clipped/%s/" %inputdir):
            # check to make sure it's a fasta file.
            if filename.endswith(".fa"):
                # make output name.
                name, extension = os.path.splitext(filename)
                # make the input name.
                input = "../preprocessing/clipped/%s/" %inputdir + filename
                # use the fastx clipper.
                os.system( "../../dependencies/bin/fastx_reverse_complement -i " + input +
                           " -o " + str(destdir + name +".RC.fa"))
