# sequence_revisions_tightclip_CEP.py
# Based on Charles Macaulays sequence revisions.py
# modified line 85 and 88: removed -d40 since this clips 40nucs 3' of adapter,
# removing parameter leads to clipping of entire msvhe as should be.
# modified by CEP 28AUG18
# sequence revisions.py
# Charles Macaulay
# 08-01-2017
# In addtion to converting the output from the Dana Farber Sequencing core to .fa files, this script executes a series
# of Fastx toolbox commands to create revised outputs.



import subprocess
import os
import sys
import shutil

# if you download .fasta from the Dana Farber Sequencing Core, the file extension is still .seq. So the first step is
# converting these files to the appropriate .fasta files.
def gen_faseqs( inputdir ):
    # check to make sure the directory to hold the changed .fa sequences exists. if it doesn't. create it.
    if os.path.isdir("../curated_sequences/%s/faseqs/" %inputdir):
        # the output path is fine.
        destdir = "../curated_sequences/%s/faseqs/" %inputdir
    else:
        # the output directory needs to be created.
        os.makedirs("../curated_sequences/%s/faseqs/" %inputdir)
        destdir = "../curated_sequences/%s/faseqs/" %inputdir

    # loop through all of the fasta files in the CombinedGCFasta directory.
    for filename in os.listdir("../curated_sequences/%s/" %inputdir ):
        if filename.endswith(".seq"):
            # strip off the .seq
            name, extension = os.path.splitext(filename)
            newname = name + ".fa"
            shutil.copy2(str("../curated_sequences/%s/" %inputdir +filename), str(destdir + newname))

# runs the fasta formatter to output single-line files to single_line directory.
def gen_singlelines( inputdir ):
    # loop through all of the fasta files in the CombinedGCFasta directory.
    for filename in os.listdir("../curated_sequences/%s/faseqs/" %inputdir ):
        # check to make sure it's a fasta file.
        if filename.endswith(".fa"):
            # make output name.
            name, extension = os.path.splitext(filename)
            # check to see if output directory must be created.
            # if it exists,
            if os.path.isdir("../preprocessing/single_line/%s/" %inputdir):
                # the output path is fine.
                output = "../preprocessing/single_line/%s/" %inputdir + name + ".singleline.fa"
            else:
                # the output directory needs to be created.
                os.makedirs("../preprocessing/single_line/%s/" %inputdir)
                output = "../preprocessing/single_line/%s/" %inputdir + name + ".singleline.fa"

            # make input name.
            input = "../curated_sequences/%s/faseqs/" %inputdir + filename
            # use fasta formatter to make single line FASTA
            os.system( "../../dependencies/bin/fasta_formatter -i " + input + " -o " + output + " -w 0")
        else:
            continue

# runs the fastx clipper to output clipped files to clipped directory.
def gen_clipped( inputdir, adapterseq=None ):
    # loop through all of the single-line fasta files in single_line.
    for filename in os.listdir("../preprocessing/single_line/%s/" %inputdir ):
        # check to make sure it's a fasta file.
        if filename.endswith(".fa"):
            # make output name.
            name, extension = os.path.splitext(filename)

            # check to see if output directory must be created.
            # if it exists,
            if os.path.isdir("../preprocessing/clipped/%s/" %inputdir):
                # the output path is fine.
                output = "../preprocessing/clipped/%s/" %inputdir + name + ".clipped.fa"
            else:
                # the output directory needs to be created.
                os.makedirs("../preprocessing/clipped/%s/" %inputdir)
                output = "../preprocessing/clipped/%s/" %inputdir + name + ".clipped.fa"

            # make the input name.
            input = "../preprocessing/single_line/%s/" %inputdir + filename
            # use the fastx clipper.
            if adapterseq:
                os.system( "../../dependencies/bin/fastx_clipper -a %s -c -n -i" %adapterseq + input +
                           " -o " + output)
            else:
                os.system( "../../dependencies/bin/fastx_clipper -a CCAGACTCC -c -n -i" + input +
                           " -o "  + output)

# runs the fastx reverse complement on clipped fastas and outputs revcomp seqs to rev_comps directory.
def gen_revcomps( inputdir ):
    # loop through all of the single-line fasta files in single_line.
    for filename in os.listdir("../preprocessing/clipped/%s/" %inputdir):
        # check to make sure it's a fasta file.
        if filename.endswith(".fa"):
            # make output name.
            name, extension = os.path.splitext(filename)

            # check to see if output directory must be created.
            # if it exists,
            if os.path.isdir("../preprocessing/rev_comps/%s/" %inputdir):
                # the output path is fine.
                output = "../preprocessing/rev_comps/%s/" %inputdir + name + ".revcomp.fa"
            else:
                # the output directory needs to be created.
                os.makedirs("../preprocessing/rev_comps/%s/" %inputdir)
                output = "../preprocessing/rev_comps/%s/" %inputdir + name + ".revcomp.fa"

            # make the input name.
            input = "../preprocessing/clipped/%s/" %inputdir + filename
            # use the fastx clipper.
            os.system( "../../dependencies/bin/fastx_reverse_complement -i " + input + " -o " + output)

# main function
if __name__ == "__main__":

    # for the specified input directory:

    if (len(sys.argv)<2):
        print( "SYNTAX ERROR with sequence_revisions.py, please provide the desired directory of "
               "curated .fa files within curated_sequences" )
    inputdir = str(sys.argv[1])

    # if there's a custom adapter sequence it will be sys.argv[2]
    if (len(sys.argv)>2):
        adapterseq = str(sys.argv[2])
    else:
        adapterseq =None

    # call the function to rename all of the sequences to .fa from .seq
    gen_faseqs(inputdir)
    # call the function to generate single-line fasta files.
    gen_singlelines(inputdir)
    # call function to use fastx clipper.
    gen_clipped(inputdir, adapterseq)
    # call function to use fastx reverse complements.
    gen_revcomps(inputdir)