# pipeline_script.py
# Charles Macaulay
# 04-11-2018
# This is the script that pulls together sequence_revisions.py, blastn_runner.py, and parsed_sequence.py in order to
# 1: preprocess the .seq files from the Dana Farber sequencing core using Fastx
#     - convert each to a .fa file
#     - write each sequence to a single line
#     - clip off the adapter sequence
#     - write the reverse complement sequence
# 2: query the IMGT and NCBI databases with each reverse complement .fa sequence using igblastn
# 3: read through the IgBlast output and store the important information from each sequence in a Parsed_sequence object
#    which can then easily write to an output file.

# IMPORTS

# classes I've built.
# the sequence_revisor class (from sequence_revisor.py)
import sequence_revisor as SR
# the blastn_runner class (from blastn_runner.py)
import blastn_runner as BR
# the blast_parser class from (from blast_parser.py)
import blast_parser as BP
# the parsed_sequence class (from parsed_sequence.py)
import parsed_sequence as PS

# other things.
# for file management stuff.
import os
# for getting user input.
import sys
# for checking the time.
import datetime

# for doing operations on data
import math
from Bio import pairwise2


# Set up global variable for holding the path we are using for the pipeline.
abs_path_to_src = os.path.abspath((os.path.dirname(__file__)))

# Get the current time so that we can use it to not overwrite files.
timestamp = str(datetime.datetime.now().time())

# Handle user input.
# Make sure the user has specified folder and mode.
# The expected input is:
# python pipeline_script.py <folder(required)> <mode(optional)> <adaptersequence(optional)>
if (len(sys.argv) < 2):
    print "USAGE ERROR\nPLEASE PROVIDE ALL REQUIRED COMMANDS\nEXAMPLE:\n"
    print "python pipeline_script.py <folder(required)> <mode(optional)> <adaptersequence(optional)>"
    exit()

# Store the values from user input in variables:
# the user might try to put an integer or something in there.
try:
    querydir = str(sys.argv[1])
except:
    print "USAGE ERROR\nPLEASE PROVIDE ALL REQUIRED COMMANDS\nEXAMPLE:\n"
    print "python pipeline_script.py <folder(required)> <mode(optional)> <adaptersequence(optional)>"
    exit()

mode = None
# If mode is given
if (len(sys.argv)>2):
    # mode is assigned the third input.
    mode = sys.argv[2]

adapter_seq = None
# If custom adapter sequence is given
if (len(sys.argv)>3):
    # adapter_seq is assigned the fourth input.
    adapter_seq = sys.argv[3]

# explain to the user that they need to provide genotype names where at least one of the strings is present in the
# filenames.
print "When providing input to identify genotypes to compare, please write alphanumeric genotypes that are substrings" \
      "present in the filenames of the files you're putting through the pipeline."

# ask the user for the genotypes being compared in the analysis.
gen1 = raw_input("please type the first genotype you are interested in looking at:  ")
gen2 = raw_input("please type the second genotype you are interested in looking at:  ")


# first, we need to run the preprocessing on each sequence.
# initialize a sequence revisor object
seq_revisor = SR.Sequence_revisor(mode)
# generate fastas
seq_revisor.gen_faseqs(querydir)
# generate single lines
seq_revisor.gen_singlelines(querydir)
# generate sequences with clipped adapters
seq_revisor.gen_clipped(querydir, adapter_seq)
# generate the reverse complement sequences.
seq_revisor.gen_revcomps(querydir)

# now, we can use the reverse complement sequences to query the reference databases using IgBlast
# initialize a blast runner
b_runner = BR.Blastn_runner()
# query the database using IMGT.
b_runner.query_with_IMGT(querydir)
# query the database with NCBI.
b_runner.query_with_NCBI(querydir)



# The part where we run through all of the igblast output and put select parts together into a parsed output.
# This works by creating a blast parser object for each .txt igblast output file and a parsed blast object for
# each sequence. This function returns a list of parsed seq objects.
def transfer_to_parsed(refdatabase, mode=None):
    igblast_output_path = str("../igblast_query_outputs/" + refdatabase +"/%s/" % querydir)

    # outer list to hold lists of parsed sequences
    outerpslist = []
    # Loop through all of the files in the iblast output directory.
    for outputfile in os.listdir(igblast_output_path):
        # check to make sure that we're dealing with a .txt file.
        if not (str(outputfile).endswith(".txt")):
            continue
        # initialize blast parser object.
        b_parser = BP.Blast_parser()
        # set up a list to hold each parsed sequence.
        pslist = []
        # invoke the blast parser's read method.
        dictlist = b_parser.read(os.path.join(abs_path_to_src, str(igblast_output_path + outputfile)))
        # initialize a mutation sequence for each sequence
        # iterate and check amino acid mismatch number.
        # to keep track of where we are in lists.
        iterator = 0
        for (kvhseq,vvhseq) in dictlist[0][0].items():
            ms = PS.Parsed_sequence()
            ms.ofile = outputfile
            ms.num_total_nuc_mismatches = dictlist[0][2][iterator]
            a = ms.set_productive_nuc_AA( str(kvhseq[4:]), "Vh query")
            b = ms.set_productive_nuc_AA( str(vvhseq[4:]), "Vh ref")
            if (a == 1) and (b == 1):
                queryAA = ms.query_VH_AA_seq
                refAA = ms.reference_VH_AA_seq
                align = pairwise2.align.globalms(queryAA,refAA,2,0,-2,-1)
                nummismatches = 0.0
                mismatch_list =[]
                for b in range(0, len(align[0][0])):
                    if (align[0][0][b] != "-") and (align[0][1][b] != "-"):
                        if align[0][0][b] != align[0][1][b]:
                            nummismatches +=1
                            mismatch_list.append(align[0][0][b])
                ms.mismatched_VH_AA = mismatch_list
                ms.sort_mismatched_VH_AAlist()
                ms.num_VH_AA_mismatches = nummismatches
                pslist.append(ms)
                iterator += 1
            else:
                ms.mismatched_VH_AA = []
                ms.sort_mismatched_VH_AAlist("N/A")
                ms.num_VH_AA_mismatches = 0
                pslist.append(ms)
                iterator += 1

        # iterate through and set the id fields.
        i = 0
        for key, val in dictlist[0][1].items():
            tempms = pslist[i]
            tempms.queryID = str(key)
            tempms.vh = str(val)
            pslist[i] = tempms
            i+=1

        i = 0
        for cdr3list in dictlist[1][0]:
            tempms = pslist[i]
            tempms.set_productive_nuc_AA( cdr3list[i][4:], "CDR3 query")
            tempms.calc_isoelectric_CDR3()
            pslist[i] = tempms
            i +=1
        outerpslist.append(pslist)
    return outerpslist

# opening the output files
# check to see that the appropriate directories exists and, if it doesn't, create it.
# if they both exist,
if ((os.path.exists("../parsed_igblast_query_outputs/NCBI/%s/" % querydir)) and
    (os.path.exists("../parsed_igblast_query_outputs/IMGT/%s/" % querydir))):
    # output paths are fine so we can just open them.
    ncbi_out = open(("../parsed_igblast_query_outputs/NCBI/%s/" % querydir
                     + "Parsed_IgBlast.NCBI.%s.txt" %querydir), "w")
    imgt_out = open(("../parsed_igblast_query_outputs/IMGT/%s/" % querydir
                     + "Parsed_IgBlast.NCBI.%s.txt" %querydir), "w")
else:
    # the output directories needs to be created first.
    os.makedirs("../parsed_igblast_query_outputs/NCBI/%s/" % querydir)
    os.makedirs("../parsed_igblast_query_outputs/IMGT/%s/" % querydir)
    ncbi_out = open(("../parsed_igblast_query_outputs/NCBI/%s/" % querydir
                     + "Parsed_IgBlast.NCBI.%s.txt" %querydir), "w")
    imgt_out = open(("../parsed_igblast_query_outputs/IMGT/%s/" % querydir
                     + "Parsed_IgBlast.NCBI.%s.txt" %querydir), "w")


# execute the transfer function defined above in order to get lists of parsed sequences.
ncbi_ps_list = transfer_to_parsed("NCBI")
imgt_ps_list = transfer_to_parsed("IMGT")

# write the header in each output file.
ncbi_out.write("GCfile\tPopulation\tIsotype\tQuery ID\tReference VH\t# Nucleotide mismatches\t# Amino acid mismatches"
                "\tQuery sequence\tReference sequence\tQuery translated\tReference translated\tpos proportion\t"
                "neg proportion\tpolarproportion\tnonpolarproportion\tCDR3 nucleotide sequence\tCDR3 AA sequence\t"
                "CDR3 isoE point\tCDR3 length\n")
imgt_out.write("GCfile\tPopulation\tIsotype\tQuery ID\tReference VH\t# Nucleotide mismatches\t# Amino acid mismatches"
                "\tQuery sequence\tReference sequence\tQuery translated\tReference translated\tpos proportion\t"
                "neg proportion\tpolarproportion\tnonpolarproportion\tCDR3 nucleotide sequence\tCDR3 AA sequence\t"
                "CDR3 isoE point\tCDR3 length\n")

# write the output from each parsed sequence from the appropriate list of parsed sequences. (NCBI)
for parseseqlist in ncbi_ps_list:
    iterator = 0
    for parseseq in parseseqlist:
        ncbi_out.write(parseseq.ofile+"\t")
        if gen1 in parseseq.ofile:
            ncbi_out.write("%s\t" %gen1)
        elif gen2 in parseseq.ofile:
            ncbi_out.write("%s\t" %gen2)
        else:
            ncbi_out.write("N/A\t")
        if "IgM" in parseseq.queryID:
            ncbi_out.write("IgM\t")
        elif "IgG" in parseseq.queryID:
            ncbi_out.write("IgG\t")
        elif "Kin" in parseseq.queryID:
            ncbi_out.write("Kappa\t")
        else:
            ncbi_out.write("N/A\t")
        mutationtypes = parseseq.mismatched_VH_types
        if len(mutationtypes) == 0:
            continue
        ncbi_out.write(parseseq.queryID+"\t"+parseseq.vh+"\t"+str(parseseq.num_total_nuc_mismatches)+"\t"
                    +str(parseseq.num_VH_AA_mismatches)+"\t"
                    +str(parseseq.query_VH_nuc_seq)+"\t"
                    +str(parseseq.reference_VH_nuc_seq)+"\t"
                    +str(parseseq.query_VH_AA_seq)+"\t"
                    +str(parseseq.reference_VH_AA_seq)+"\t"
                    +str(mutationtypes[0])+"\t"
                    +str(mutationtypes[1])+"\t"
                    +str(mutationtypes[2])+"\t"
                    +str(mutationtypes[3])+"\t"
                    +str(parseseq.query_CDR3_nuc_seq)+"\t"
                    +str(parseseq.query_CDR3_AA_seq)+"\t"
                    +str(parseseq.isoelectricpoint)+"\t"
                    +str(parseseq.cdr3_length)+"\n")
        iterator += 1
ncbi_out.close()

# write the output from each parsed sequence from the appropriate list of parsed sequences. (IMGT)
for parseseqlist in imgt_ps_list:
    iterator = 0
    for parseseq in parseseqlist:
        imgt_out.write(parseseq.ofile+"\t")
        if gen1 in parseseq.ofile:
            imgt_out.write("%s\t"%gen1)
        elif gen2 in parseseq.ofile:
            imgt_out.write("%s\t"%gen2)
        else:
            imgt_out.write("N/A\t")
        if "IgM" in parseseq.queryID:
            imgt_out.write("IgM\t")
        elif "IgG" in parseseq.queryID:
            imgt_out.write("IgG\t")
        elif "Kin" in parseseq.queryID:
            imgt_out.write("Kappa\t")
        else:
            imgt_out.write("N/A\t")
        mutationtypes = parseseq.mismatched_VH_types
        if len(mutationtypes) == 0:
            continue
        imgt_out.write(parseseq.queryID+"\t"+parseseq.vh+"\t"+str(parseseq.num_total_nuc_mismatches)+"\t"
                    +str(parseseq.num_VH_AA_mismatches)+"\t"
                    +str(parseseq.query_VH_nuc_seq)+"\t"
                    +str(parseseq.reference_VH_nuc_seq)+"\t"
                    +str(parseseq.query_VH_AA_seq)+"\t"
                    +str(parseseq.reference_VH_AA_seq)+"\t"
                    +str(mutationtypes[0])+"\t"
                    +str(mutationtypes[1])+"\t"
                    +str(mutationtypes[2])+"\t"
                    +str(mutationtypes[3])+"\t"
                    +str(parseseq.query_CDR3_nuc_seq)+"\t"
                    +str(parseseq.query_CDR3_AA_seq)+"\t"
                    +str(parseseq.isoelectricpoint)+"\t"
                    +str(parseseq.cdr3_length)+"\n")
        iterator += 1
imgt_out.close()
