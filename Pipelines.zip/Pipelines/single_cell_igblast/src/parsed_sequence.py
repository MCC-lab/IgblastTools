# parsed_sequence.py
# Charles Macaulay
# started 12-01-2017
# updated 04-11-2018

# this file defines the ParsedSequence class, which is basically a container for all of the data that we want to put
# in our consolidated, easier-to-use output.


# libraries to import
import os
import csv
from collections import defaultdict
from collections import OrderedDict
import string
import random
import sys
import math
# These are all packages from the Biopython library.
# URL for Biopython documentation: http://biopython.org/wiki/Documentation
from Bio.SeqUtils.ProtParam import ProteinAnalysis
from Bio import SeqIO
from Bio.Seq import Seq
from Bio.Alphabet import generic_dna
from Bio import pairwise2
from Bio.pairwise2 import format_alignment
import codecs


# This class holds information on the AA and nucleotide mismatches pulled from an IgBlast output file.
class Parsed_sequence:
    # initialize the ParsedSequence fields
    def __init__(self):
        # the folder containing the sequence.
        self.ofile = ""
        # the ID of the query made to IgBlast
        self.queryID = ""

        # Fields for storing information about the Variable Heavy chain:

        # number of amino acid mismatches between the query and reference Vh
        self.num_VH_AA_mismatches = 0
        # number of nucleotide mismatches across the whole variable chain
        self.num_total_nuc_mismatches = 0
        # the query VH Seq is stored here.
        self.query_VH_nuc_seq = Seq("")
        # the reference VH Seq is stored here.
        self.reference_VH_nuc_seq = Seq("")
        # the translated query VH Seq is stored here.
        self.query_VH_AA_seq = ""
        # the translated reference VH Seq is stored here.
        self.reference_VH_AA_seq = ""
        # the list of mismatched AA is is stored here.
        self.mismatched_VH_AA = []
        # the Vh identified by IgBlast
        self.vh = ""
        # the list of sorted AA mismatch types
        self.mismatched_VH_types = []

        # Fields for storing information about the CDR3 region:

        # number of amino acid mismatches between the query and reference CDR3
        self.num_CDR3_AA_mismatches = 0
        # number of nucleotide mismatches across the CDR3
        self.num_CDR3_nuc_mismatches = 0
        # the query CDR3 Seq is stored here.
        self.query_CDR3_nuc_seq = Seq("")
        # the reference CDR3 Seq is stored here.
        self.reference_CDR3_nuc_seq = Seq("")
        # the translated query CDR3 Seq is stored here.
        self.query_CDR3_AA_seq = ""
        # the translated reference CDR3 Seq is stored here.
        self.reference_CDR3_AA_seq = ""
        # the list of mismatched AA is is stored here.
        self.mismatched_CDR3_AA = []
        # the list of sorted AA mismatch types
        self.mismatched_CDR3_types = [] 
        # to store the isoelectric point of the query CDR3 AA sequence.
        self.isoelectricpoint = 0.0
        # to store the length of the CDR3 sequence.
        self.cdr3_length = 0

    # Special AA methods

    # function that sets the isoelectric point of the queries CDR3 AA sequence.
    def calc_isoelectric_CDR3(self):
        # check to make sure the query sequence has been set.
        if len(self.query_CDR3_AA_seq) == 0:
            print "Query Seq has not been set yet"
            self.isoelectricpoint = "N/A"
            return
        # if it has indeed been set
        else:
            isoseq = str(self.query_CDR3_AA_seq)
            side_chain_charges = []
            for c in isoseq:
                if c == "Y":
                    side_chain_charges.append(10.46)
                elif c == "H":
                    side_chain_charges.append(6.04)
                elif c == "C":
                    side_chain_charges.append(8.37)
                elif c == "D":
                    side_chain_charges.append(3.90)
                elif c == "E":
                    side_chain_charges.append(4.07)
                elif c == "K":
                    side_chain_charges.append(10.54)
                elif c == "R":
                    side_chain_charges.append(12.48)
            if len(side_chain_charges) > 0:
                self.isoelectricpoint = sum(side_chain_charges)/len(side_chain_charges)
            else:
                self.isoelectricpoint = "NEUTRAL"


    # function to sort the mismatched VH AA's by charge and return the ratio of positively charged AA's.
    def sort_mismatched_VH_AAlist(self, flag=None):
        poscharged_total = 0.0
        negcharged_total = 0.0
        polar_total = 0.0
        nonpolar_total = 0.0
        mismatched_total = float(len(self.mismatched_VH_AA))
        if (flag == "N/A") or (mismatched_total == 0.0):
            self.mismatched_VH_types = ["N/A","N/A","N/A","N/A"]
        else:
            for AA in self.mismatched_VH_AA:
                if (str(AA) == "H" or str(AA) == "R" or str(AA) == "K"):
                    poscharged_total += 1
                elif (str(AA) == "D" or str(AA) == "E"):
                    negcharged_total += 1
                elif (str(AA) == "S" or str(AA) == "T" or str(AA) == "C"or str(AA) == "Y"or str(AA) == "N"
                      or str(AA) == "Q"):
                    polar_total +=1
                elif (str(AA) == "G" or str(AA) == "A" or str(AA) == "P"or str(AA) == "V"or str(AA) == "L"
                      or str(AA) == "I" or str(AA) == "M"or str(AA) == "F"or str(AA) == "W"):
                    nonpolar_total +=1
                else:
                    continue
            self.mismatched_VH_types = [poscharged_total/mismatched_total, negcharged_total/mismatched_total,
                    polar_total/mismatched_total, nonpolar_total/mismatched_total]

            if self.mismatched_VH_types == []:
                print"EMPTY MISMATCH LIST"
                self.mismatched_VH_types = [0.0,0.0,0.0,0.0]

    # function to sort the mismatched CDR3 AA's by charge and return the ratio of positively charged AA's.
    def sort_mismatched_CDR3_AAlist(self):
        poscharged_total = 0.0
        negcharged_total = 0.0
        polar_total = 0.0
        nonpolar_total = 0.0
        mismatched_total = float(len(self.mismatched_CDR3_AA))
        if mismatched_total == 0.0:
            self.mismatchedtypes = [0.0,0.0,0.0,0.0]
        else:
            for AA in self.mismatched_CDR3_AA:
                if (str(AA) == "H" or str(AA) == "R" or str(AA) == "K"):
                    poscharged_total += 1
                elif (str(AA) == "D" or str(AA) == "E"):
                    negcharged_total += 1
                elif (str(AA) == "S" or str(AA) == "T" or str(AA) == "C"or str(AA) == "Y"or str(AA) == "N"
                      or str(AA) == "Q"):
                    polar_total +=1
                elif (str(AA) == "G" or str(AA) == "A" or str(AA) == "P"or str(AA) == "V"or str(AA) == "L"
                      or str(AA) == "I" or str(AA) == "M"or str(AA) == "F"or str(AA) == "W"):
                    nonpolar_total +=1
                else:
                    continue
            self.mismatched_CDR3_types = [poscharged_total/mismatched_total, negcharged_total/mismatched_total,
                    polar_total/mismatched_total, nonpolar_total/mismatched_total]

    # finds the productive translation of a given sequence. S is just a a string of nucleotides. sequence is whether
    # the sequence being passed in is the Vh or CDR3 sequence.
    def set_productive_nuc_AA(self, s, sequence):
        for i in range(0,3):
            test_rf = Seq(s[i:])
            try:
                translated = test_rf.translate()
                if any("*" in s for s in str(translated[0:-3])):
                    pass
                else:
                    if sequence == "Vh query":
                        self.query_VH_nuc_seq = test_rf
                        self.query_VH_AA_seq = test_rf.translate()
                    elif sequence == "Vh ref":
                        self.reference_VH_nuc_seq = test_rf
                        self.reference_VH_AA_seq = test_rf.translate()
                    elif sequence == "CDR3 query":
                        self.cdr3_length = len(test_rf.translate())
                        self.query_CDR3_nuc_seq = test_rf
                        self.query_CDR3_AA_seq = test_rf.translate()
                    elif sequence == "CDR3 ref":
                        self.reference_CDR3_nuc_seq = test_rf
                        self.reference_CDR3_AA_seq = test_rf.translate()
                    return 1
            except:
                continue
        if sequence == "Vh query":
            self.query_VH_nuc_seq = Seq(s)
            self.query_VH_AA_seq = ""
        elif sequence == "Vh ref":
            self.reference_VH_nuc_seq = Seq(s)
            self.reference_VH_AA_seq = ""
        elif sequence == "CDR3 query":
            self.query_CDR3_nuc_seq = Seq(s)
            self.query_CDR3_AA_seq = ""
        elif sequence == "CDR3 ref":
            self.reference_CDR3_nuc_seq = Seq(s)
            self.reference_CDR3_AA_seq = ""
        return -1