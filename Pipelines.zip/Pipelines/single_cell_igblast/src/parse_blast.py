# parse_blast_output.py
# Charles Macaulay
# Started 12-01-2017

# this file defines two classes--ParsedSequence, which can be used to hold the information parsed from the IgBlast
# output file and analyze nucleotide and amino acid mutations; and BlastParser which is used to actually read through
# the output files from IgBlast. The main function of this file completes the following tasks based on the parsed data
# from the IgBlast output file:
# 1: alignment of query and reference Vh
# 2: alignment of query and reference CDR3
#       -- in this case the reference CDR3 comes from Cloanalyst UCA files, not the IgBlast output file.
# 3: uses methods of each ParsedSequence object to sort amino acid mutations
# 4: uses methods of each ParsedSequence object to get the isoelectric point for query CDR3 amino acid sequences.


# libraries to import
import os
import csv
from collections import defaultdict
from collections import OrderedDict
import string
import random
import sys
import math
# These are all packages from the Biopython library.
# URL for Biopython documentation: http://biopython.org/wiki/Documentation
from Bio.SeqUtils.ProtParam import ProteinAnalysis
from Bio import SeqIO
from Bio.Seq import Seq
from Bio.Alphabet import generic_dna
from Bio import pairwise2
from Bio.pairwise2 import format_alignment
import codecs

debug = True

# debugfile = open("mutation_debug.txt", "w")

# This class holds information on the AA and nucleotide mismatches pulled from an IgBlast output file.
class ParsedSequence:
    # initialize the ParsedSequence fields
    def __init__(self):
        # the ID of the query made to IgBlast
        self.queryID = ""

        # Fields for storing information about the Variable Heavy chain:

        # number of amino acid mismatches between the query and reference Vh
        self.num_VH_AA_mismatches = 0
        # number of nucleotide mismatches across the whole variable chain
        self.num_total_nuc_mismatches = 0
        # the query VH Seq is stored here.
        self.query_VH_nuc_seq = Seq("")
        # the reference VH Seq is stored here.
        self.reference_VH_nuc_seq = Seq("")
        # the translated query VH Seq is stored here.
        self.query_VH_AA_seq = ""
        # the translated reference VH Seq is stored here.
        self.reference_VH_AA_seq = ""
        # the list of mismatched AA is is stored here.
        self.mismatched_VH_AA = []
        # the Vh identified by IgBlast
        self.vh = ""
        # the list of sorted AA mismatch types
        self.mismatched_VH_types = []

        # Fields for storing information about the CDR3 region:

        # number of amino acid mismatches between the query and reference CDR3
        self.num_CDR3_AA_mismatches = 0
        # number of nucleotide mismatches across the CDR3
        self.num_CDR3_nuc_mismatches = 0
        # the query CDR3 Seq is stored here.
        self.query_CDR3_nuc_seq = Seq("")
        # the reference CDR3 Seq is stored here.
        self.reference_CDR3_nuc_seq = Seq("")
        # the translated query CDR3 Seq is stored here.
        self.query_CDR3_AA_seq = ""
        # the translated reference CDR3 Seq is stored here.
        self.reference_CDR3_AA_seq = ""
        # the list of mismatched AA is is stored here.
        self.mismatched_CDR3_AA = []
        # the list of sorted AA mismatch types
        self.mismatched_CDR3_types = [] 
        # to store the isoelectric point of the query CDR3 AA sequence.
        self.isoelectricpoint = 0.0
        # to store the length of the CDR3 sequence.
        self.cdr3_length = 0

    # Getter and setter functions for the ParsedSequence object

    # function to set the ParsedSequence object's query ID.
    def set_queryID(self, s):
        self.queryID = s

    # function to get the ParsedSequence object's query ID.
    def get_queryID(self):
        return self.queryID

    # Functions for dealing with Vh's:
    
    # function to set the ParsedSequence object's number of AA mismatches
    def set_VH_AA_mismatches(self, x):
        self.num_VH_AA_mismatches = x

    # function to get the ParsedSequence object's number of AA mismatches
    def get_VH_AA_mismatches(self):
        return self.num_VH_AA_mismatches

    # function to set the ParsedSequence object's number of nucleotide mismatches
    def set_total_nuc_mismatches(self, x):
        self.num_total_nuc_mismatches = x

    # function to get the ParsedSequence object's number of nucleotide mismatches
    def get_total_nuc_mismatches(self):
        return self.num_total_nuc_mismatches

    # function to set the ParsedSequence object's query Vh nucleotide sequence. Input must be a Seq object.
    def set_query_VH_nuc(self, s):
        self.query_VH_nuc_seq = s

    # function to get the ParsedSequence object's query Vh nucleotide sequence. Input must be a Seq object.
    def get_query_VH_nuc(self):
        return self.query_VH_nuc_seq

    # function to set the ParsedSequence object's reference Vh nucleotide sequence identified by IgBlast. Input must be
    # a Seq object.
    def set_ref_VH_nuc(self, s):
        self.reference_VH_nuc_seq = s

    # function to set the ParsedSequence object's reference Vh nucleotide sequence identified by IgBlast. Input must be
    # a Seq object.
    def get_ref_VH_nuc(self):
        return self.reference_VH_nuc_seq

    # function to set the ParsedSequence object's query Vh AA sequence
    def set_query_VH_AA(self, s):
        self.query_VH_AA_seq = s

    # function to set the ParsedSequence object's query Vh AA sequence
    def get_query_VH_AA(self):
        return self.query_VH_AA_seq

    # function to set the ParsedSequence object's reference Vh AA sequence
    def set_ref_VH_AA(self, s):
        self.query_VH_AA_seq = s

    # function to get the ParsedSequence object's reference Vh AA sequence
    def get_ref_VH_AA(self):
        return self.query_VH_AA_seq

    # function to set the ParsedSequence object's identified Vh.
    def set_VhID(self, s):
        self.vh = s

    # function to get the ParsedSequence object's identified Vh.
    def get_VhID(self):
        return self.vh

    # function to set the ParsedSequence object's mismatched Vh AA list.
    def set_mismatched_VH_AAlist(self, l):
        self.mismatched_VH_AA = l

    # function to get the ParsedSequence object's mismatched Vh AA list.
    def get_mismatched_VH_AAlist(self):
        return self.mismatched_VH_AA

    # Functions for dealing with CDR3's:

    # function to set the ParsedSequence object's number of AA mismatches
    def set_CDR3_AA_mismatches(self, x):
        self.num_CDR3_AA_mismatches = x

    # function to get the ParsedSequence object's number of AA mismatches
    def get_CDR3_AA_mismatches(self):
        return self.num_CDR3_AA_mismatches

    # function to set the ParsedSequence object's query CDR3 nucleotide sequence. Input must be a Seq object.
    def set_query_CDR3_nuc(self, s):
        self.query_CDR3_nuc_seq = s

    # function to get the ParsedSequence object's query CDR3 nucleotide sequence. Input must be a Seq object.
    def get_query_CDR3_nuc(self):
        return self.query_CDR3_nuc_seq

    # function to set the ParsedSequence object's reference CDR3 nucleotide sequence identified by IgBlast. Input must be
    # a Seq object.
    def set_ref_CDR3_nuc(self, s):
        self.reference_CDR3_nuc_seq = s

    # function to get the ParsedSequence object's reference CDR3 nucleotide sequence identified by IgBlast. Input must be
    # a Seq object.
    def get_ref_CDR3_nuc(self):
        return self.reference_CDR3_nuc_seq

    # function to set the ParsedSequence object's query CDR3 AA sequence
    def set_query_CDR3_AA(self, s):
        self.query_CDR3_AA_seq = s

    # function to get the ParsedSequence object's query CDR3 AA sequence
    def get_query_CDR3_AA(self):
        return self.query_CDR3_AA_seq

    # function to set the ParsedSequence object's reference CDR3 AA sequence
    def set_ref_CDR3_AA(self, s):
        self.query_CDR3_AA_seq = s

    # function to get the ParsedSequence object's reference CDR3 AA sequence
    def get_ref_CDR3_AA(self):
        return self.query_CDR3_AA_seq

    # function to set the ParsedSequence object's mismatched CDR3 AA list.
    def set_mismatched_CDR3_AAlist(self, l):
        self.mismatched_CDR3_AA = l

    # function to get the ParsedSequence object's mismatched CDR3 AA list.
    def get_mismatched_CDR3_AAlist(self):
        return self.mismatched_CDR3_AA

    # sets the CDR3 length.
    def set_cdr3_length(self, len):
        self.cdr3_length = len

    # gets the CDR3 length.
    def get_cdr3_length(self):
        return self.cdr3_length

    # Special AA methods

    # function that sets the isoelectric point of the queries CDR3 AA sequence.
    def calc_isoelectric_CDR3(self):
        # check to make sure the query sequence has been set.
        if len(self.get_query_CDR3_AA()) == 0:
            print "Query Seq has not been set yet"
            self.isoelectricpoint = "N/A"
            return
        # if it has indeed been set
        else:
            # isoseq = ProteinAnalysis(str(self.get_query_CDR3_AA()))
            # self.isoelectricpoint = isoseq.isoelectric_point()
            isoseq = str(self.get_query_CDR3_AA())
            side_chain_charges = []
            for c in isoseq:
                if c == "Y":
                    side_chain_charges.append(10.46)
                elif c == "H":
                    side_chain_charges.append(6.04)
                elif c == "C":
                    side_chain_charges.append(8.37)
                elif c == "D":
                    side_chain_charges.append(3.90)
                elif c == "E":
                    side_chain_charges.append(4.07)
                elif c == "K":
                    side_chain_charges.append(10.54)
                elif c == "R":
                    side_chain_charges.append(12.48)
            if len(side_chain_charges) > 0:
                self.isoelectricpoint = sum(side_chain_charges)/len(side_chain_charges)
            else:
                self.isoelectricpoint = "NEUTRAL"


    # function to sort the mismatched VH AA's by charge and return the ratio of positively charged AA's.
    def sort_mismatched_VH_AAlist(self, flag=None):
        poscharged_total = 0.0
        negcharged_total = 0.0
        polar_total = 0.0
        nonpolar_total = 0.0
        mismatched_total = float(len(self.mismatched_VH_AA))
        if (flag == "N/A") or (mismatched_total == 0.0):
            self.mismatched_VH_types = ["N/A","N/A","N/A","N/A"]
        else:
            for AA in self.mismatched_VH_AA:
                if (str(AA) == "H" or str(AA) == "R" or str(AA) == "K"):
                    poscharged_total += 1
                elif (str(AA) == "D" or str(AA) == "E"):
                    negcharged_total += 1
                elif (str(AA) == "S" or str(AA) == "T" or str(AA) == "C"or str(AA) == "Y"or str(AA) == "N"
                      or str(AA) == "Q"):
                    polar_total +=1
                elif (str(AA) == "G" or str(AA) == "A" or str(AA) == "P"or str(AA) == "V"or str(AA) == "L"
                      or str(AA) == "I" or str(AA) == "M"or str(AA) == "F"or str(AA) == "W"):
                    nonpolar_total +=1
                else:
                    continue
            self.mismatched_VH_types = [poscharged_total/mismatched_total, negcharged_total/mismatched_total,
                    polar_total/mismatched_total, nonpolar_total/mismatched_total]

            if self.mismatched_VH_types == []:
                print"EMPTY MISMATCH LIST"
                self.mismatched_VH_types = [0.0,0.0,0.0,0.0]

    # returns the list of mismatched proportions that's currently stored in the mismatched_VH_types field.
    def get_VH_mismatched_VH_types(self):
        return self.mismatched_VH_types

    # function to sort the mismatched CDR3 AA's by charge and return the ratio of positively charged AA's.
    def sort_mismatched_CDR3_AAlist(self):
        poscharged_total = 0.0
        negcharged_total = 0.0
        polar_total = 0.0
        nonpolar_total = 0.0
        mismatched_total = float(len(self.mismatched_CDR3_AA))
        if mismatched_total == 0.0:
            self.mismatchedtypes = [0.0,0.0,0.0,0.0]
        else:
            for AA in self.mismatched_CDR3_AA:
                if (str(AA) == "H" or str(AA) == "R" or str(AA) == "K"):
                    poscharged_total += 1
                elif (str(AA) == "D" or str(AA) == "E"):
                    negcharged_total += 1
                elif (str(AA) == "S" or str(AA) == "T" or str(AA) == "C"or str(AA) == "Y"or str(AA) == "N"
                      or str(AA) == "Q"):
                    polar_total +=1
                elif (str(AA) == "G" or str(AA) == "A" or str(AA) == "P"or str(AA) == "V"or str(AA) == "L"
                      or str(AA) == "I" or str(AA) == "M"or str(AA) == "F"or str(AA) == "W"):
                    nonpolar_total +=1
                else:
                    continue
            self.mismatched_CDR3_types = [poscharged_total/mismatched_total, negcharged_total/mismatched_total,
                    polar_total/mismatched_total, nonpolar_total/mismatched_total]

    # finds the productive translation of a given sequence. S is just a a string of nucleotides. sequence is whether
    # the sequence being passed in is the Vh or CDR3 sequence.
    def set_productive_nuc_AA(self, s, sequence):
        for i in range(0,3):
            test_rf = Seq(s[i:])
            try:
                translated = test_rf.translate()
                if any("*" in s for s in str(translated[0:-3])):
                    pass
                else:
                    if sequence == "Vh query":
                        self.query_VH_nuc_seq = test_rf
                        self.query_VH_AA_seq = test_rf.translate()
                    elif sequence == "Vh ref":
                        self.reference_VH_nuc_seq = test_rf
                        self.reference_VH_AA_seq = test_rf.translate()
                    elif sequence == "CDR3 query":
                        self.set_cdr3_length( len(test_rf.translate()))
                        self.set_query_CDR3_nuc(test_rf)
                        self.set_query_CDR3_AA(test_rf.translate())
                    elif sequence == "CDR3 ref":
                        self.reference_CDR3_nuc_seq = test_rf
                        self.reference_CDR3_AA_seq = test_rf.translate()
                    return 1
            except:
                continue
        if sequence == "Vh query":
            self.query_VH_nuc_seq = Seq(s)
            self.query_VH_AA_seq = ""
        elif sequence == "Vh ref":
            self.reference_VH_nuc_seq = Seq(s)
            self.reference_VH_AA_seq = ""
        elif sequence == "CDR3 query":
            self.query_CDR3_nuc_seq = Seq(s)
            self.reference_CDR3_AA_seq = ""
        elif sequence == "CDR3 ref":
            self.reference_CDR3_nuc_seq = Seq(s)
            self.reference_CDR3_AA_seq = ""
        return -1


# This class is designed to parse the blast output file from, in this case, a given germinal center.
class BlastParser:
    def __init__(self):
        # fields for Vh information
        self.sequence_dict_Vh = OrderedDict()
        self.id_dict_Vh = OrderedDict()
        self.nucleotide_mutations_Vh = []
        # fields for CDR3 information
        self.sequence_dict_CDR3 = []
        self.id_list_CDR3 = []
        self.nucleotide_mutations_CDR3 = []

    # returns a list with two items:
    # 0 - list of outputs for Vh: the sequence_dict_Vh OrderedDict, id_dict_Vh OrderedDict, and nucleotide_mutations_Vh
    # list.
    # 1 - list of outputs for CDR3: the sequence_dict_CDR3 OrderedDict, id_dict_CDR3 OrderedDict, and
    # nucleotide_mutations_CDR3 list.
    def read(self, filepath):
        query_id_list = []
        identified_Vh_list = []
        # To store the query and reference sequences translated
        query_Vh_nuc_seq = []
        query_CDR3_nuc_seq = []
        reference_Vh_nuc_seq = []
        # temporary variables used to deal with cases where output has partial read
        temp_query_id = ""
        temp_vh_id = ""
        temp_cdr3_junctions = []
        temp_cdr3_qseq = ""
        temp_nuc_mutations = 0.0

        with open(filepath) as igblast_output_file:
            statemachine = "A"
            reader = csv.reader(igblast_output_file, delimiter="\t")
            for line in reader:
                # find the line where the query is designated.
                if any("# Query: " in s for s in line):
                    if (statemachine == "A"):
                        temp_query_id = line[0]
                        # debugfile.write("query ID: " + line[0] + "\n")
                if (statemachine == "B"):
                    temp_vh_id = line[0]
                    statemachine = "C"
                if any("# V-(D)-J rearrangement" in s for s in line):
                    if (statemachine == "A"):
                        statemachine = "B"
                else:
                    # need this extra try statement to handle lines that are 0 in length.
                    try:
                        if (any("# V-(D)-J junction" in s for s in line) and (statemachine == "C")):
                            statemachine = "D"
                            continue
                        if statemachine == "D":
                            vend = line[0]
                            vend = vend.replace("N/A", "")
                            vd = line[1]
                            vd = vd.replace("N/A", "")
                            d = line[2]
                            d = d.replace("N/A", "")
                            dj = line[3]
                            dj = dj.replace("N/A", "")
                            j = line[4]
                            j = j.replace("N/A", "")
                            temp_cdr3_junctions = [vend, vd, d, dj, j]
                            statemachine = "E"
                        if ((line[0] == "CDR3") and (statemachine == "E")):
                            cdr3_qseq = line[1]
                            try:
                                # generate random barcode to keep sequences unique.
                                bc = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(4))
                                # starting with cutting off the first nucleotide.
                                temp_cdr3_qseq = bc + cdr3_qseq
                                statemachine = "F"
                            except:
                                print("WARNING, ERROR IN CDR3 TRANSLATION", temp_query_id)
                                bc = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(4))
                                temp_cdr3_qseq = (bc + "N/A")
                                statemachine = "F"

                        if (line[0] == "Total")and(statemachine =="F"):
                            temp_nuc_mutations = int(line[5])
                            # debugfile.write("number of nucleotide mutations: " + line[5] + "\n")
                            statemachine = "G"
                        if ((line[0] == "V") and (statemachine == "G")):
                            try:
                                # generate random barcode to keep sequences unique.
                                bc = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(4))
                                # starting with cutting off the first nucleotide.
                                temp_query_vh_nuc_seq  = bc + str(line[3])
                                # the reference sequence is already cut to the same starting point as the query seq.
                                temp_reference_vh_nuc_seq = bc + str(line[5])
                                statemachine = "A"
                                ''' Means that the state machine has successfully completed the cycle so we can
                                transfer the temporary variables over without fear of having read an impartial output.'''
                                query_id_list.append(temp_query_id)
                                identified_Vh_list.append(temp_vh_id)
                                cdr3_junctions = temp_cdr3_junctions
                                query_CDR3_nuc_seq.append(temp_cdr3_qseq)
                                self.nucleotide_mutations_Vh.append(temp_nuc_mutations)#/float(len(line[3])))
                                query_Vh_nuc_seq.append(temp_query_vh_nuc_seq)
                                reference_Vh_nuc_seq.append(temp_reference_vh_nuc_seq)

                            # if the queries don't get translated well, they're ignored for now.
                            except:
                                print("WARNING, ERROR IN Vh TRANSLATION", temp_query_id)
                                bc = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(4))
                                query_Vh_nuc_seq.append(bc + "N/A")
                                reference_Vh_nuc_seq.append(bc + "N/A")
                                statemachine = "A"
                    except:
                        pass

            for i in range( 0, len(query_id_list)):
                self.id_dict_Vh[query_id_list[i]] = identified_Vh_list[i]
                self.id_list_CDR3.append(query_id_list[i])
                self.sequence_dict_Vh[query_Vh_nuc_seq[i]] = reference_Vh_nuc_seq[i]
                self.sequence_dict_CDR3.append(query_CDR3_nuc_seq)

        return [[self.sequence_dict_Vh, self.id_dict_Vh, self.nucleotide_mutations_Vh],
                [self.sequence_dict_CDR3, self.id_list_CDR3, self.nucleotide_mutations_CDR3]]

# main function
if __name__ == "__main__":

    # Ask the user if they want to look at NCBI or IMGT output.
    if len(sys.argv) < 3:
        print "ERROR: please provide the database output: either 'NCBI' or 'IMGT' followed by the directory name" \
              "containing the igblast output you'd like to analyze."
        exit()

    # the second argument after the command to run this python script dictates whether to use NCBI or IMGT output.
    igblast_output_path = "../igblast_query_outputs/" + str(sys.argv[1]) + "/" + str(sys.argv[2]) + "/"

    # check to see that the appropriate directory exists and, if it doesn't, create it.
    # if it exists,
    if (os.path.exists("../parsed_igblast_query_outputs/" + str(sys.argv[1]) + "/" + str(sys.argv[2])+"/")):
        # the output path is fine, so open the output file.
        ofile = open(("../parsed_igblast_query_outputs/" + str(sys.argv[1]) + "/" + str(sys.argv[2]) +"/"
                      + "Parsed_IGBLAST_" + str(sys.argv[1]) + "_" + str(sys.argv[2]) + ".txt"), "w")
    else:
        # the output directory needs to be created.
        os.makedirs("../parsed_igblast_query_outputs/" + str(sys.argv[1]) + "/" + str(sys.argv[2])+"/")
        ofile = open(("../parsed_igblast_query_outputs/" + str(sys.argv[1]) + "/" + str(sys.argv[2]) +"/"
                      + "Parsed_IGBLAST_" + str(sys.argv[1]) + "_" + str(sys.argv[2]) + ".txt"), "w")


    # Write out the header for the text file.
    ofile.write("GCfile\tPopulation\tIsotype\tQuery ID\tReference VH\t# Nucleotide mismatches\t# Amino acid mismatches"
                "\tRatio\tQuery sequence\tReference sequence\tQuery translated\tReference translated\tpos proportion\t"
                "neg proportion\tpolarproportion\tnonpolarproportion\tCDR3 nucleotide sequence\tCDR3 AA sequence\t"
                "CDR3 isoE point\tCDR3 length\n")

    for outputfile in os.listdir(igblast_output_path):

        # check to make sure that we're dealing with a .txt file.
        if not (str(outputfile).endswith(".txt")):
            continue
        mslist = []
        # initialize and have the reader read.
        reader = BlastParser()
        abspath = os.path.abspath((os.path.dirname(__file__)))
        path = os.path.join(abspath, str(igblast_output_path + outputfile))
        dictlist = reader.read(path)
        # initialize a mutation sequence for each sequence
        # iterate and check amino acid mismatch number.
        # to keep track of where we are in lists.
        iterator = 0
        for (kvhseq,vvhseq) in dictlist[0][0].items():
            ms = ParsedSequence()
            # debugfile.write("NUCLEOTIDE MUTATIONS:"+ str(dictlist[0][2][iterator]))
            ms.num_total_nuc_mismatches = dictlist[0][2][iterator]
            a = ms.set_productive_nuc_AA(str(kvhseq[4:]), "Vh query")
            b = ms.set_productive_nuc_AA(str(vvhseq[4:]), "Vh ref")
            if (a == 1) and (b == 1):
                queryAA = ms.query_VH_AA_seq
                refAA = ms.reference_VH_AA_seq
                align = pairwise2.align.globalms(queryAA,refAA,2,0,-2,-1)
                nummismatches = 0.0
                mismatch_list =[]
                for b in range(0, len(align[0][0])):
                    if (align[0][0][b] != "-") and (align[0][1][b] != "-"):
                        if align[0][0][b] != align[0][1][b]:
                            nummismatches +=1
                            mismatch_list.append(align[0][0][b])
                ms.set_mismatched_VH_AAlist(mismatch_list)
                ms.sort_mismatched_VH_AAlist()
                ms.set_VH_AA_mismatches(nummismatches)#/float(len(queryAA)))
                mslist.append(ms)
                iterator += 1
            else:
                ms.set_mismatched_VH_AAlist([])
                ms.sort_mismatched_VH_AAlist("N/A")
                ms.set_VH_AA_mismatches(0)
                mslist.append(ms)
                iterator += 1

        # iterate through and set the id fields.
        i = 0
        for key, val in dictlist[0][1].items():
            tempms = mslist[i]
            tempms.set_queryID(str(key))
            tempms.set_VhID(str(val))
            mslist[i] = tempms
            attbs = vars(tempms)
            i+=1

        i = 0
        for cdr3list in dictlist[1][0]:
            tempms = mslist[i]
            sequence = cdr3list[i]
            tempms.set_productive_nuc_AA(cdr3list[i][4:], "CDR3 query")
            tempms.calc_isoelectric_CDR3()
            mslist[i] = tempms
            i +=1

        for parseseq in mslist:
            ofile.write(outputfile+"\t")
            if "B6" in outputfile:
                ofile.write("B6\t")
            else:
                ofile.write("CD32\t")
            if "IgM" in parseseq.queryID:
                ofile.write("IgM\t")
            elif "IgG" in parseseq.queryID:
                ofile.write("IgG\t")
            else:
                ofile.write("Kappa\t")
            mutationtypes = parseseq.get_VH_mismatched_VH_types()
            if len(mutationtypes) == 0:
                continue
            ofile.write(parseseq.queryID+"\t"+parseseq.vh+"\t"+str(parseseq.num_total_nuc_mismatches)+"\t"
                        +str(parseseq.num_VH_AA_mismatches)+"\t"
                        +str(math.log((parseseq.num_total_nuc_mismatches+.0000001)/(parseseq.num_VH_AA_mismatches+.0000001)))+"\t"
                        +str(parseseq.query_VH_nuc_seq)+"\t"
                        +str(parseseq.reference_VH_nuc_seq)+"\t"
                        +str(parseseq.query_VH_AA_seq)+"\t"
                        +str(parseseq.reference_VH_AA_seq)+"\t"
                        +str(mutationtypes[0])+"\t"
                        +str(mutationtypes[1])+"\t"
                        +str(mutationtypes[2])+"\t"
                        +str(mutationtypes[3])+"\t"
                        +str(parseseq.query_CDR3_nuc_seq)+"\t"
                        +str(parseseq.query_CDR3_AA_seq)+"\t"
                        +str(parseseq.isoelectricpoint)+"\t"
                        +str(parseseq.cdr3_length)+"\n")
    ofile.close()
    # debugfile.close()
